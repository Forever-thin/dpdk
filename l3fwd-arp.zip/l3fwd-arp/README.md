# dpdk-l3fwd-acl

dpdk l3fwd-acl with arp reply and icmp echo reply supported

Edit the main.c code and put the IP address for the respective port in ipaddr_per_port variable. 

## 4. 实现简单三层转发  
一个绑定至少3端口的dpdk程序，预先设定各端口地址及前缀长度。针对特定L3目的地址，能通过最长前缀匹配找到对应的端口。  
## 5. 实现ARP  
与主机正常通信
